#include<stdio.h>

int main(){
    float a = 0.124;
    printf("%.2f", a);
        return 0;
}