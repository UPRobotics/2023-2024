import rclpy
from rclpy.node import Node
from formatos.srv import Movearm

class Cambios_ejes(Node):
    def __init__(self):
        super().__init__("table_server")
        self.service = self.create_service(Movearm, "cambio_ejes", self.serviceCallback)
        self.get_logger().info("Service add an array is ready")

    def serviceCallback(self, req, res):
        self.get_logger().info(f"New Request Received 1: {req.armi[0]}, 2: {req.armi[1]}, 3: {req.armi[2]}, 4: {req.armi[3]}, 5: {req.armi[4]}, 6: {req.armi[5]}")
        res.armi = [req.armi[0], req.armi[1],req.armi[2],req.armi[3],req.armi[4],req.armi[5]]
        self.get_logger().info("Returning arreglo: %d" % res.armi) 

        return res
        

def main():
    rclpy.init()
    cambios_server=Cambios_ejes()
    rclpy.spin(cambios_server)
    cambios_server.destroy_node()
    rclpy.shutdown()

if __name__=="__main__":
    main()